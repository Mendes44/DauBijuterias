const menuButton = document.querySelector('.mobile-menu');
const links = document.querySelector('.links');
const playButton = document.querySelector('.play');

menuButton.addEventListener('click', () => {
  links.classList.toggle('open');
});

playButton.addEventListener('click', () => {
  alert('Adicione o vídeo da DauBijuterias neste espaço para ativar a demonstração.');
});

document.querySelectorAll('.links a').forEach((link) => {
  link.addEventListener('click', () => links.classList.remove('open'));
});